// cacheStorage API
// https://developer.mozilla.org/zh-CN/docs/Web/API/CacheStorage

var cacheName = 'pwa-cache-v1';
var cacheList = [];
// install事件
self.addEventListener('install', function (e) {
  e.waitUntil(self.skipWaiting());
});
// 激活事件
self.addEventListener('activate', function (e) {
  e.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', function (event) {
  const url = new URL(event.request.url);
  if (url.pathname !== '/pwa.html') {
    event.respondWith(
      caches.match(event.request, {
        ignoreSearch: true,
      }).then(function (response) {
        if (response) {
          return response;
        }
        var requestToCache = event.request.clone();
        return fetch(requestToCache).then((response) => {
          if (!response || response.status !== 200) {
            return response;
          }
          var responseToCache = response.clone();
          caches.open(cacheName).then(function (cache) {
            cache.put(requestToCache, responseToCache);
          });
          return response;
        })
      })
    )
  }
});
