importScripts('https://g.alicdn.com/kg/workbox/3.3.0/workbox-sw.js');
workbox.setConfig({
  modulePathPrefix: 'https://g.alicdn.com/kg/workbox/3.3.0/'
});
if (workbox) {
  console.log(`Yay! Workbox is loaded 🎉`);
} else {
  console.log(`Boo! Workbox didn't load 😬`);
}
workbox.routing.registerRoute(
  new RegExp('.*\.(jpg|png)$'),
  workbox.strategies.staleWhileRevalidate()
);
workbox.routing.registerRoute(
  new RegExp('.*\.html'),
  workbox.strategies.networkFirst()
);
// workbox.routing.registerRoute(
//   new RegExp(),
//   workbox.strategies.networkOnly()
// );
// workbox.routing.registerRoute(
//   new RegExp('.*\.(?:js|css)'),
//   workbox.strategies.cacheFirst()
// );
// workbox.routing.registerRoute(
//   new RegExp(),
//   workbox.strategies.cacheOnly()
// );
// // 自定义策略
// const handlerCb = ({url, event, params}) => {
//   var supportWebp = false;
//   if (event.request.headers.has('accept')) {
//     supportWebp = event.request.headers.get('accept').includes('webp');
//   }
//   if (supportWebp) {
//     var req = event.request.clone();
//     var returnUrl = req.url.substr(0, req.url.lastIndexOf('.')) + '.webp';
//     return fetch(returnUrl, {
//       mode: 'no-cors',
//     }).then((response) => {
//       return response;
//     });
//   }
// };
// workbox.routing.registerRoute(
//   new RegExp('.*\.png$'),
//   handlerCb,
// );